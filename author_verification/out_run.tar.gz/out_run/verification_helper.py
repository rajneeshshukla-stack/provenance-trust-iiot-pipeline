#!/usr/bin/env python3
"""Helper of run_author_verification.sh (standard library; psutil if present). Subcommands:
env OUT_JSON EXECUTOR REPO PROVERIF | tree REPO OUT_JSON | hashes REPO OUT_JSON |
proverif STORED OUT_JSON NEW_LOG... | summary OUT REPO | redact OUT REPO HOME"""
import datetime as dt
import difflib
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path

IGNORED_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache"}
IGNORED_FILES = {".DS_Store", "Thumbs.db", "desktop.ini"}
REVIEWED = ["src/pbti/b5_corrected.py", "src/pbti/b5.py", "src/pbti/verifier.py", "src/pbti/review.py",
            "src/pbti/registry.py", "src/pbti/envelope.py", "tests/test_b5_corrected.py", "docs/BASELINES.md",
            "formal/LOCALITY_PROOF.md", "formal/PROOF_REVIEW_CHECKLIST.md", "formal/pbti.pv",
            "formal/pbti_variant_nocompromise.pv", "formal/pbti_variant_otlink_attacker.pv",
            "results/formal/proverif_output.txt", "RELEASE_TREE_MANIFEST.json"]
STORED_V4 = ["A0_core", "A1_review", "A3_selective", "A3_scenarios", "A3_factorial"]
ADDED_IN_V9 = "src/pbti/b5_corrected.py"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def run(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return ""


def cpu_model():
    if sys.platform == "darwin":
        return run(["sysctl", "-n", "machdep.cpu.brand_string"]) or platform.processor()
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.lower().startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine()


def mem_gib():
    try:
        import psutil
        return round(psutil.virtual_memory().total / 2**30, 1)
    except Exception:
        pass
    if sys.platform == "darwin":
        v = run(["sysctl", "-n", "hw.memsize"])
        return round(int(v) / 2**30, 1) if v.isdigit() else None
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                return round(int(line.split()[1]) / 2**20, 1)
    except OSError:
        pass
    return None


def os_name():
    if sys.platform == "darwin":
        return f"macOS {platform.mac_ver()[0]}"
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if line.startswith("PRETTY_NAME="):
                return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return platform.platform()


def src_digest(repo, exclude=()):
    h = hashlib.sha256()
    for p in sorted((repo / "src").rglob("*.py")):
        rel = p.relative_to(repo).as_posix()
        if rel in exclude or any(part in IGNORED_DIRS for part in p.relative_to(repo).parts):
            continue
        h.update(rel.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def cmd_env(out, who, repo, proverif):
    import importlib.metadata as md
    pins = {}
    for line in Path(repo, "requirements.txt").read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "==" in line:
            n, v = line.split("==", 1)
            pins[n.strip()] = v.strip()
    pk = {}
    for n, v in pins.items():
        try:
            got = md.version(n)
        except Exception:
            got = None
        pk[n] = {"pinned": v, "installed": got, "match": got == v}
    pv = run([proverif, "-help"])
    env = {"executor": who, "time_utc": now(),
           "time_local": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
           "os": os_name(), "kernel": platform.release(), "machine": platform.machine(),
           "windows_subsystem_for_linux": "microsoft" in platform.release().lower(),
           "cpu_model": cpu_model(), "logical_cpus": os.cpu_count(), "memory_gib": mem_gib(),
           "python": sys.version.split()[0], "python_implementation": platform.python_implementation(),
           "packages": pk, "packages_match_pins": all(v["match"] for v in pk.values()),
           "proverif": pv.splitlines()[0] if pv else None, "workers": os.environ.get("WORKERS"),
           "note": "host name, user name and absolute paths are intentionally not recorded"}
    Path(out).write_text(json.dumps(env, indent=1))
    print(json.dumps(env, indent=1))
    return 0


def cmd_tree(repo, out):
    repo = Path(repo)
    man = json.loads((repo / "RELEASE_TREE_MANIFEST.json").read_text())
    files, ignored = [], []
    for p in sorted(repo.rglob("*")):
        rel = p.relative_to(repo)
        if any(part in IGNORED_DIRS for part in rel.parts) or p.name in IGNORED_FILES:
            if p.is_file():
                ignored.append(rel.as_posix())
            continue
        if p.is_file() and rel.as_posix() != "RELEASE_TREE_MANIFEST.json":
            files.append(p)
    h = hashlib.sha256()
    for p in files:
        h.update(p.relative_to(repo).as_posix().encode() + b"\0" + bytes.fromhex(sha(p)))
    res = {"time_utc": now(), "tree_sha256_expected": man.get("tree_sha256"), "tree_sha256_found": h.hexdigest(),
           "files_expected": man.get("files"), "files_found": len(files),
           "ignored_system_files": ignored[:50], "n_ignored_system_files": len(ignored)}
    res["match"] = res["tree_sha256_expected"] == res["tree_sha256_found"]
    if not res["match"]:
        res["hint"] = ("the repository differs from the delivered one; run the SHA256SUMS.txt check in the "
                       "research package folder to see which files changed")
    Path(out).write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))
    return 0 if res["match"] else 1


def cmd_hashes(repo, out):
    repo = Path(repo)
    res = {"files": {f: (sha(repo / f) if (repo / f).exists() else None) for f in REVIEWED}}
    stored = {}
    for n in STORED_V4:
        m = repo / "results" / "v4" / "raw" / f"{n}.manifest.json"
        if m.exists():
            stored[n] = json.loads(m.read_text()).get("source_sha256")
    res["source_digest_src_all"] = src_digest(repo)
    res["source_digest_without_" + Path(ADDED_IN_V9).name] = src_digest(repo, (ADDED_IN_V9,))
    res["source_digest_stored_v4_manifests"] = stored
    Path(out).write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))
    return 0


def result_lines(path):
    return [line.rstrip() for line in Path(path).read_text(errors="replace").splitlines() if line.startswith("RESULT")]


def cmd_proverif(stored, out, *new_logs):
    s = result_lines(stored)
    n, per = [], {}
    for f in new_logs:
        lines = result_lines(f)
        per[Path(f).name] = len(lines)
        n += lines
    res = {"stored_result_lines": len(s), "new_result_lines": len(n), "per_model": per, "identical": s == n,
           "diff": list(difflib.unified_diff(s, n, "stored", "new", lineterm=""))[:200]}
    Path(out).write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))
    return 0 if res["identical"] else 1


def load(p):
    try:
        return json.loads(Path(p).read_text())
    except Exception:
        return None


def cmd_summary(out, repo):
    out, repo = Path(out), Path(repo)
    steps = []
    for line in (out / "steps.tsv").read_text().splitlines()[1:]:
        f = line.split("\t")
        steps.append({"step": f[0], "exit": f[1], "start": f[2], "end": f[3]})
    env = load(out / "environment.json") or {}
    before, after = load(out / "integrity_before.json") or {}, load(out / "integrity_after.json") or {}
    hashes = load(out / "file_hashes.json") or {}
    rx = load(out / "reexecution" / "reexecution_comparison.json")
    pvc = load(out / "proverif_compare.json")
    st = {s["step"]: s["exit"] for s in steps}

    def tail(name, pat):
        try:
            txt = (out / name).read_text(errors="replace")
        except OSError:
            return None
        m = re.findall(pat, txt)
        return m[-1] if m else None

    areas = []
    areas.append(("Repository integrity (before and after)",
                  "PASS" if before.get("match") and after.get("match") else "CHECK",
                  f"tree SHA-256 {before.get('tree_sha256_found', '?')[:16]}… vs manifest "
                  f"{before.get('tree_sha256_expected', '?')[:16]}…; {before.get('files_found')} files; "
                  f"unchanged after the run: {after.get('match')}"))
    areas.append(("Frozen-file check (scripts/verify_prereg_hashes.py)",
                  "PASS" if st.get("03_frozen_files") == "0" else "CHECK", f"exit {st.get('03_frozen_files')}"))
    passed = tail("04_regression_tests.log", r"(\d+ passed[^\n]*)")
    areas.append(("Corrected-comparator regression tests (tests/test_b5_corrected.py)",
                  "PASS" if st.get("04_regression_tests") == "0" else "CHECK",
                  f"exit {st.get('04_regression_tests')}; {passed or 'no pytest summary found'}"))
    rx_status, rx_detail = "NOT RUN", "skipped"
    if rx:
        t = rx.get("totals", {})
        sub = {s.get("step"): s.get("exit_code") for s in rx.get("steps", [])}
        lm = rx.get("a5_lifecycle_matrix") or {}
        fc = rx.get("formal_check") or {}
        dig = rx.get("digests", {})
        cfg_equal = all(d.get("config_sha256", {}).get("equal") for d in dig.values()) if dig else False
        src_new = {d.get("source_sha256", {}).get("new") for d in dig.values()}
        src_stored = {d.get("source_sha256", {}).get("stored") for d in dig.values()}
        wo = hashes.get("source_digest_without_" + Path(ADDED_IN_V9).name)
        src_explained = (src_new == {hashes.get("source_digest_src_all")} and src_stored == {wo})
        src_equal = all(d.get("source_sha256", {}).get("equal") for d in dig.values()) if dig else False
        rows_ok = (t.get("compared", 0) > 0 and t.get("different", 1) == 0 and t.get("errors_in_new", 1) == 0
                   and t.get("missing_in_stored", 1) == 0)
        subs_ok = bool(sub) and all(v == 0 for v in sub.values())
        lm_ok = not lm.get("different_or_missing") if lm else False
        fc_same = bool(fc.get("identical_excluding_timing"))
        fc_paths = fc.get("differing_paths") or []
        fc_explained = (not fc_same and bool(fc.get("all_pass_new"))
                        and fc_paths == ["/source_sha256/" + Path(ADDED_IN_V9).name])
        fc_ok = fc_same or fc_explained
        ok = rows_ok and subs_ok and lm_ok and fc_ok and cfg_equal and (src_equal or src_explained)
        rx_status = ("PASS" if src_equal and fc_same else "PASS (explained differences)") if ok else "CHECK"
        rx_detail = (f"{t.get('identical')} of {t.get('compared')} re-executed runs identical to the stored runs "
                     f"(timing fields excluded; {t.get('n_field_comparisons')} field comparisons; different "
                     f"{t.get('different')}, errors {t.get('errors_in_new')}); sub-steps {sub}; lifecycle matrix "
                     f"{lm.get('identical_rows')} of {lm.get('stored_rows')} rows identical; bounded locality check: "
                     f"all invariants pass {fc.get('all_pass_new')}, identical {fc_same}"
                     + ("" if fc_same else f" (differing fields {fc_paths}; explained: {fc_explained}, the check "
                        "records the SHA-256 of every source file and the V9 repository adds one)")
                     + f"; configuration digests equal: {cfg_equal}; "
                     f"source digest equal: {src_equal}"
                     + ("" if src_equal else f" (explained: {src_explained}; the V9 repository adds {ADDED_IN_V9}, "
                        "which these runners do not load; the digest of src/ without it equals the digest stored "
                        "with the original runs)")
                     + f". Re-execution kit's own verdict line: \"{rx.get('verdict')}\"")
    elif st.get("05_reexecution") not in (None, "SKIPPED"):
        rx_status, rx_detail = "CHECK", f"exit {st.get('05_reexecution')}; no comparison report was written"
    areas.append(("Re-execution kit (tools/reexec/reproduce_subset.sh)", rx_status, rx_detail))
    if pvc:
        areas.append(("ProVerif models (3) against the stored RESULT lines", "PASS" if pvc.get("identical") else "CHECK",
                      f"{env.get('proverif')}; {pvc.get('new_result_lines')} RESULT lines, "
                      f"{pvc.get('stored_result_lines')} stored; identical: {pvc.get('identical')}"))
    else:
        areas.append(("ProVerif models (3) against the stored RESULT lines", "NOT RUN", "ProVerif not found"))
    complete = all(a[1].startswith("PASS") for a in areas)
    summary = {"executor": env.get("executor"), "finished_utc": now(), "areas": [
        {"area": a, "status": s, "detail": d} for a, s, d in areas], "all_automated_checks_pass": complete,
        "steps": steps, "environment": env, "file_hashes": hashes.get("files")}
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    pk = env.get("packages", {})
    L = ["# PBTI V9 — author-run verification: summary", "",
         f"* Executor: {env.get('executor')}",
         f"* Started (UTC): {steps[0]['start'] if steps else '?'}; finished (UTC): {summary['finished_utc']}",
         f"* Machine: {env.get('os')} ({env.get('machine')}), {env.get('cpu_model')}, {env.get('logical_cpus')} "
         f"logical CPUs, {env.get('memory_gib')} GiB RAM, WSL: {env.get('windows_subsystem_for_linux')}",
         f"* Python {env.get('python')}; pinned packages installed: {env.get('packages_match_pins')}"
         + ("" if env.get("packages_match_pins") else " — " + ", ".join(
             f"{k} {v['installed']} (pinned {v['pinned']})" for k, v in pk.items() if not v["match"])),
         f"* ProVerif: {env.get('proverif')}", f"* WORKERS: {env.get('workers')}", "",
         "| Check | Status | Detail |", "|---|---|---|"]
    L += [f"| {a} | **{s}** | {d} |" for a, s, d in areas]
    L += ["", "All automated checks pass." if complete else
          "Not every automated check passed or ran; the details above and the logs in this folder say which.",
          "", "The manual reviews (ProVerif model assumptions, Proposition 1 proof, comparator code, manuscript) are "
          "recorded in the log sheet, not here.", "", "## Steps", "", "| Step | Exit | Start (UTC) | End (UTC) |",
          "|---|---|---|---|"]
    L += [f"| {s['step']} | {s['exit']} | {s['start']} | {s['end']} |" for s in steps]
    L += ["", "## SHA-256 of the files under review", ""]
    L += [f"* `{f}`: `{h}`" for f, h in (hashes.get("files") or {}).items()]
    (out / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0


def cmd_redact(out, repo, home):
    out = Path(out)
    subs = [(str(Path(repo)), "<REPO>"), (str(out), "<OUT>")]
    if home and home != "/":
        subs.append((home.rstrip("/"), "~"))
    for p in out.rglob("*"):
        if p.is_file() and p.suffix in {".md", ".json", ".tsv", ".log", ".txt"} and p.stat().st_size < 50_000_000:
            t = p.read_text(errors="replace")
            u = t
            for a, b in subs:
                u = u.replace(a, b)
            if u != t:
                p.write_text(u)
    return 0


if __name__ == "__main__":
    c, a = sys.argv[1], sys.argv[2:]
    sys.exit({"env": cmd_env, "tree": cmd_tree, "hashes": cmd_hashes, "proverif": cmd_proverif,
              "summary": cmd_summary, "redact": cmd_redact}[c](*a))
