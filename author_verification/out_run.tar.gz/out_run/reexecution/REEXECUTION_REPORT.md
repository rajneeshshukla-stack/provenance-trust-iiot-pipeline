# Re-execution of selected seeds: comparison with the stored results

**Verdict:** DIFFERENCES OR FAILURES FOUND - see details

* Label: Rajneesh Shukla (author-run)
* Time (UTC): 2026-11-07T10:30:24+00:00; local: 2026-11-07T04:30:24-06:00
* CPU: Intel(R) Core(TM) i5-10310U CPU @ 1.70GHz (8 logical CPUs), memory 7.65 GiB
* OS: Ubuntu 26.04.1 LTS (kernel 6.18.54.1-microsoft-standard-WSL2, x86_64); Python 3.14.4
* Packages: cryptography 50.0.1, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, matplotlib 3.11.2, PyYAML 6.0.3, psutil 7.2.2, paho-mqtt 2.1.0, pytest 9.1.1
* Git commit: not a git checkout
* Source SHA-256 (src/pbti aggregate): `0b29dadba59fef4a9e7cd96334518b8d549761fe72d31b3bab9e3caf5e0d85ca`
* Code SHA-256 (src, experiments, analysis, formal, scripts aggregate): `54078792f0137dd9b0e154eae863999996c226daf4f14dc5e137b2e5a2dbf932`

## Steps

| Step | Exit code | Start (UTC) | End (UTC) | Command |
|---|---|---|---|---|
| pytest | 0 | 2026-11-07T10:30:24Z | 2026-11-07T10:33:11Z | `python3 -m pytest -q tests/` |
| A0_core | 0 | 2026-11-07T10:33:11Z | 2026-11-07T10:47:03Z | `python3 experiments/run_v4.py experiments/v4_configs/A0_core.json --seeds 1 2 --workers 4 --out <OUT>/reexecution/A0_core_subset.jsonl` |
| A1_review | 0 | 2026-11-07T10:47:03Z | 2026-11-07T13:04:12Z | `python3 experiments/run_v4.py experiments/v4_configs/A1_review.json --seeds 21 22 --workers 4 --out <OUT>/reexecution/A1_review_subset.jsonl` |
| A3_selective | 0 | 2026-11-07T13:04:12Z | 2026-11-07T13:57:48Z | `python3 experiments/run_v4.py experiments/v4_configs/A3_selective.json --seeds 21 22 --workers 4 --out <OUT>/reexecution/A3_selective_subset.jsonl` |
| A3_scenarios | 0 | 2026-11-07T13:57:48Z | 2026-11-07T14:01:57Z | `python3 experiments/run_v4.py experiments/v4_configs/A3_scenarios.json --seeds 1 2 --workers 4 --out <OUT>/reexecution/A3_scenarios_subset.jsonl` |
| A3_factorial | 0 | 2026-11-07T14:01:57Z | 2026-11-07T14:06:39Z | `python3 experiments/run_v4.py experiments/v4_configs/amendment1/A3_factorial.json --seeds 21 22 --workers 4 --out <OUT>/reexecution/A3_factorial_subset.jsonl` |
| A5_matrix | 0 | 2026-11-07T14:06:39Z | 2026-11-07T14:06:39Z | `python3 scripts/a5_lifecycle_matrix.py` |
| formal_check | 0 | 2026-11-07T14:06:39Z | 2026-11-07T14:09:15Z | `python3 formal/v4_locality_lifecycle_check.py --out <OUT>/reexecution/v4_locality_lifecycle_check.json` |

Test suite: 199 passed, 1 skipped in 167.07s (0:02:47)

## Campaign runs

| Re-executed file | Seeds | Runs compared | Identical | Different | Errors | Field comparisons |
|---|---|---|---|---|---|---|
| A0_core_subset.jsonl | 1, 2 | 132 | 132 | 0 | 0 | 12367 |
| A1_review_subset.jsonl | 21, 22 | 176 | 176 | 0 | 0 | 19550 |
| A3_selective_subset.jsonl | 21, 22 | 294 | 294 | 0 | 0 | 29687 |
| A3_scenarios_subset.jsonl | 1, 2 | 40 | 40 | 0 | 0 | 3995 |
| A3_factorial_subset.jsonl | 21, 22 | 112 | 112 | 0 | 0 | 12282 |

Source and configuration digests as recorded by the runner (repository definition), stored campaign versus re-execution:

| Re-executed file | source_sha256 | config_sha256 | equal |
|---|---|---|---|
| A0_core_subset.jsonl | `714b9b49180be678…` | `230d4d21606a23b1…` | NO |
| A1_review_subset.jsonl | `714b9b49180be678…` | `7bb565bc8248ba66…` | NO |
| A3_selective_subset.jsonl | `714b9b49180be678…` | `4a9bf4bbcf758804…` | NO |
| A3_scenarios_subset.jsonl | `714b9b49180be678…` | `ca81520954b0b096…` | NO |
| A3_factorial_subset.jsonl | `714b9b49180be678…` | `0ce7c110265349dc…` | NO |

Totals: {"compared": 754, "identical": 754, "different": 0, "errors_in_new": 0, "n_field_comparisons": 77881, "missing_in_stored": 0, "not_reexecuted": 0}

Excluded (machine-dependent wall-clock timing): fields containing `_us`, and `wall_s`, `audit_static_s`, `audit_replay_s`.

Lifecycle matrix: 68 of 68 rows identical; different or missing: 0

Bounded formal check: all_pass stored=True, new=True; identical excluding timing: False

Scope: this compares the listed seeds only. It is not a full reproduction of every campaign, and a re-execution on the same code shows determinism and portability of the stored results, not the validity of the modelling assumptions.
